<?php
/*
Plugin Name: Quick notes
Plugin URI: http://www.keighl.com/2010/04/nonce-and-ajax/
Description: So Fast! So secure!
Version: 0.1
Author: Kyle Truscott
Author URI: http://www.keighl.com
*/

$QuickNotes = new QuickNotes();
class QuickNotes {
	
	function QuickNotes() {
		add_action('admin_menu', array(&$this, 'add_note_page'));
		add_action("admin_print_scripts", array(&$this, 'js_libs'));
		add_action('wp_ajax_quicknotes_add', array(&$this, 'add'));
	}
	
	function add_note_page() {
		add_theme_page('Quick Notes', 'Quick Notes', 'administrator', 'quick_notes', array(&$this, 'notes'));
	}
	
	function js_libs() {
		wp_enqueue_script('jquery');
	}
	
	function notes() {
		
		if ( function_exists('wp_nonce_field') )
			wp_nonce_field('quicknotes_nonce', 'quicknotes_nonce');
		
		?>
	
		<script type="text/javascript">
			
			jQuery(document).ready(function($) {
				$('#add_note').live('click',
					function () {
						note = $("#note").val();
						nonce = $("input#quicknotes_nonce").val();
						$.post(
							"<?php echo get_option('siteurl'); ?>/wp-admin/admin-ajax.php", 
							{
								action:"quicknotes_add", 
								note : note,
								nonce : nonce
							},
							function (str) {
								$('ul#note_board').html(str);
							}
						);
					}
				);
			});
			
		</script>
	
		<div class="wrap">
			<h2>Quick Notes</h2>
			<ul id="note_board"></ul>
			<p>
				<textarea id="note"></textarea>
				<a class="button" id="add_note">Add Note</a>
			</p>
		</div>
	
		<?php
	}
		
	function add() {
		
		if (!wp_verify_nonce($_POST['nonce'], 'quicknotes_nonce')) 
			exit();
		
		echo '<li>' . $_POST['note'] . '</li>';		
		exit();	
		
	}

}

?>