<?php
/*
Plugin Name: Black or White?
Plugin URI: http://www.keighl.com/2010/01/using-thickbox-in-wordpress-plugins/
Description: You choose. 
Version: 0.1
Author: Kyle Truscott
Author URI: http://www.keighl.com
*/

$BlackOrWhite = new BlackOrWhite();

class BlackOrWhite {
	
	function BlackOrWhite() {
		add_action('admin_menu', array(&$this, 'add_admin'));
		add_action("admin_print_scripts", array(&$this, 'js_libs'));
		add_action("admin_print_styles", array(&$this, 'style_libs'));
	
		add_action('wp_ajax_choice', array(&$this, 'choice'));
	}
	
	function add_admin() {
		add_theme_page('Black Or White?', 'Black Or White?', 'administrator', 'black-or-white', array(&$this, 'admin_view'));
	}
	
	function js_libs() {
		wp_enqueue_script('jquery');
		wp_enqueue_script('thickbox');
	}
	
	function style_libs() {
		wp_enqueue_style('thickbox');
	}
	
	function admin_view() {
		?>
	
		<script type="text/javascript">
			jQuery(document).ready(function($) {
				$('.choice_button').live('click',
					function () {
						var choice = $(this).attr('id');
						tb_remove();
						$('.your-choice').html(choice);
					}
				);
			});
		</script>
	
		<div class="wrap">
			<h2>Black or White?</h2>
			<p>
				<a class="thickbox button" href="<?php echo get_option('siteurl'); ?>/wp-admin/admin-ajax.php?action=choice&width=150&height=100" title="Choose">
					Choose
				</a>
			</p>
			<p>
				Your choice: <span class="your-choice"></span>
			</p>
		</div>
	
		<?php
	}
		
	function choice() {
		?>
		<p>
			<a class="button choice_button" id="Black">Black</a> 
			<a class="button choice_button" id="White">White</a>
		</p>
		<?php
		exit();
	}

}

?>